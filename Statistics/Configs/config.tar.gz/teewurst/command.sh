./runExperiment.sh 40 60 > experiment.log
